package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.security.PublicKey;

public class Batting_Stats_DialogBox_Controller {

    @FXML
    public Label Batting_Style_Label;
    @FXML
    public Label Batting_Rank_Label;
    @FXML
    public Label Total_Hundreds_Label;
    @FXML
    public Label Total_Fifties_Label;
    @FXML
    public Label Best_Score_Label;





}
