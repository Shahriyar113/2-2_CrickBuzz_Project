package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Team_Stats_DialogBox_Controller {

    @FXML
    public Label ODI_Match_Played_Label;
    public Label ODI_Won_Label;
    public Label ODI_Lost_Label;
    public Label ODI_Drawn_Label;

    public Label T20_Match_Played_Label;
    public Label T20_Won_Label;
    public Label T20_Lost_Label;
    public Label T20_Drawn_Label;

    public Label Test_Match_Played_Label;
    public Label Test_Won_Label;
    public Label Test_Lost_Label;
    public Label Test_Drawn_Label;





}
