package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Bowling_Stats_DialogBox_Controller {

    @FXML
    public Label Bowling_Style_Label;
    @FXML
    public Label Bowling_Rank_Label;
    @FXML
    public Label Economy_Label;
    @FXML
    public Label Total_Wickets_Label;
    @FXML
    public Label Best_Figure_Label;



}
